﻿
namespace Hotel_Reservation_System
{
    partial class Bill
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Bill));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.guna2Button4 = new Guna.UI2.WinForms.Guna2Button();
            this.txtResult = new System.Windows.Forms.RichTextBox();
            this.guna2Button3 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button2 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            this.txttot = new Guna.UI2.WinForms.Guna2TextBox();
            this.txttotnights = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtrprice = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtrid = new Guna.UI2.WinForms.Guna2TextBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Coral;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1175, 110);
            this.panel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(273, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(391, 36);
            this.label1.TabIndex = 0;
            this.label1.Text = "Hotel Management System";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel2.BackgroundImage")));
            this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel2.Controls.Add(this.guna2Button4);
            this.panel2.Controls.Add(this.txtResult);
            this.panel2.Controls.Add(this.guna2Button3);
            this.panel2.Controls.Add(this.guna2Button2);
            this.panel2.Controls.Add(this.guna2Button1);
            this.panel2.Controls.Add(this.txttot);
            this.panel2.Controls.Add(this.txttotnights);
            this.panel2.Controls.Add(this.txtrprice);
            this.panel2.Controls.Add(this.txtrid);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 110);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1175, 590);
            this.panel2.TabIndex = 1;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // guna2Button4
            // 
            this.guna2Button4.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.guna2Button4.CheckedState.Parent = this.guna2Button4;
            this.guna2Button4.CustomImages.Parent = this.guna2Button4;
            this.guna2Button4.FillColor = System.Drawing.Color.BlanchedAlmond;
            this.guna2Button4.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button4.ForeColor = System.Drawing.Color.White;
            this.guna2Button4.HoverState.Parent = this.guna2Button4;
            this.guna2Button4.Image = ((System.Drawing.Image)(resources.GetObject("guna2Button4.Image")));
            this.guna2Button4.Location = new System.Drawing.Point(391, 34);
            this.guna2Button4.Name = "guna2Button4";
            this.guna2Button4.ShadowDecoration.Parent = this.guna2Button4;
            this.guna2Button4.Size = new System.Drawing.Size(81, 46);
            this.guna2Button4.TabIndex = 8;
            this.guna2Button4.Click += new System.EventHandler(this.guna2Button4_Click);
            // 
            // txtResult
            // 
            this.txtResult.Font = new System.Drawing.Font("Comic Sans MS", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtResult.Location = new System.Drawing.Point(546, 34);
            this.txtResult.Name = "txtResult";
            this.txtResult.Size = new System.Drawing.Size(608, 492);
            this.txtResult.TabIndex = 7;
            this.txtResult.Text = "";
            // 
            // guna2Button3
            // 
            this.guna2Button3.CheckedState.Parent = this.guna2Button3;
            this.guna2Button3.CustomImages.Parent = this.guna2Button3;
            this.guna2Button3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button3.ForeColor = System.Drawing.Color.White;
            this.guna2Button3.HoverState.Parent = this.guna2Button3;
            this.guna2Button3.Location = new System.Drawing.Point(386, 461);
            this.guna2Button3.Name = "guna2Button3";
            this.guna2Button3.ShadowDecoration.Parent = this.guna2Button3;
            this.guna2Button3.Size = new System.Drawing.Size(130, 65);
            this.guna2Button3.TabIndex = 6;
            this.guna2Button3.Text = "Print";
            // 
            // guna2Button2
            // 
            this.guna2Button2.CheckedState.Parent = this.guna2Button2;
            this.guna2Button2.CustomImages.Parent = this.guna2Button2;
            this.guna2Button2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button2.ForeColor = System.Drawing.Color.White;
            this.guna2Button2.HoverState.Parent = this.guna2Button2;
            this.guna2Button2.Location = new System.Drawing.Point(238, 461);
            this.guna2Button2.Name = "guna2Button2";
            this.guna2Button2.ShadowDecoration.Parent = this.guna2Button2;
            this.guna2Button2.Size = new System.Drawing.Size(130, 65);
            this.guna2Button2.TabIndex = 5;
            this.guna2Button2.Text = "Generate ";
            this.guna2Button2.Click += new System.EventHandler(this.guna2Button2_Click);
            // 
            // guna2Button1
            // 
            this.guna2Button1.CheckedState.Parent = this.guna2Button1;
            this.guna2Button1.CustomImages.Parent = this.guna2Button1;
            this.guna2Button1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button1.ForeColor = System.Drawing.Color.White;
            this.guna2Button1.HoverState.Parent = this.guna2Button1;
            this.guna2Button1.Location = new System.Drawing.Point(92, 461);
            this.guna2Button1.Name = "guna2Button1";
            this.guna2Button1.ShadowDecoration.Parent = this.guna2Button1;
            this.guna2Button1.Size = new System.Drawing.Size(130, 65);
            this.guna2Button1.TabIndex = 4;
            this.guna2Button1.Text = "Calculate";
            this.guna2Button1.Click += new System.EventHandler(this.guna2Button1_Click);
            // 
            // txttot
            // 
            this.txttot.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txttot.DefaultText = "";
            this.txttot.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txttot.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txttot.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txttot.DisabledState.Parent = this.txttot;
            this.txttot.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txttot.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txttot.FocusedState.Parent = this.txttot;
            this.txttot.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txttot.HoverState.Parent = this.txttot;
            this.txttot.Location = new System.Drawing.Point(116, 352);
            this.txttot.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txttot.Name = "txttot";
            this.txttot.PasswordChar = '\0';
            this.txttot.PlaceholderText = "Total";
            this.txttot.SelectedText = "";
            this.txttot.ShadowDecoration.Parent = this.txttot;
            this.txttot.Size = new System.Drawing.Size(339, 87);
            this.txttot.TabIndex = 3;
            // 
            // txttotnights
            // 
            this.txttotnights.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txttotnights.DefaultText = "";
            this.txttotnights.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txttotnights.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txttotnights.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txttotnights.DisabledState.Parent = this.txttotnights;
            this.txttotnights.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txttotnights.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txttotnights.FocusedState.Parent = this.txttotnights;
            this.txttotnights.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txttotnights.HoverState.Parent = this.txttotnights;
            this.txttotnights.Location = new System.Drawing.Point(116, 257);
            this.txttotnights.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txttotnights.Name = "txttotnights";
            this.txttotnights.PasswordChar = '\0';
            this.txttotnights.PlaceholderText = "Total Nights";
            this.txttotnights.SelectedText = "";
            this.txttotnights.ShadowDecoration.Parent = this.txttotnights;
            this.txttotnights.Size = new System.Drawing.Size(339, 46);
            this.txttotnights.TabIndex = 2;
            this.txttotnights.TextChanged += new System.EventHandler(this.txttotnights_TextChanged);
            // 
            // txtrprice
            // 
            this.txtrprice.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtrprice.DefaultText = "";
            this.txtrprice.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtrprice.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtrprice.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtrprice.DisabledState.Parent = this.txtrprice;
            this.txtrprice.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtrprice.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtrprice.FocusedState.Parent = this.txtrprice;
            this.txtrprice.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtrprice.HoverState.Parent = this.txtrprice;
            this.txtrprice.Location = new System.Drawing.Point(116, 143);
            this.txtrprice.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtrprice.Name = "txtrprice";
            this.txtrprice.PasswordChar = '\0';
            this.txtrprice.PlaceholderText = "Room Price";
            this.txtrprice.SelectedText = "";
            this.txtrprice.ShadowDecoration.Parent = this.txtrprice;
            this.txtrprice.Size = new System.Drawing.Size(339, 46);
            this.txtrprice.TabIndex = 1;
            // 
            // txtrid
            // 
            this.txtrid.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtrid.DefaultText = "";
            this.txtrid.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtrid.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtrid.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtrid.DisabledState.Parent = this.txtrid;
            this.txtrid.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtrid.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtrid.FocusedState.Parent = this.txtrid;
            this.txtrid.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtrid.HoverState.Parent = this.txtrid;
            this.txtrid.Location = new System.Drawing.Point(23, 34);
            this.txtrid.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtrid.Name = "txtrid";
            this.txtrid.PasswordChar = '\0';
            this.txtrid.PlaceholderText = "Room ID";
            this.txtrid.SelectedText = "";
            this.txtrid.ShadowDecoration.Parent = this.txtrid;
            this.txtrid.Size = new System.Drawing.Size(339, 46);
            this.txtrid.TabIndex = 0;
            // 
            // Bill
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1175, 700);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Bill";
            this.Text = "Bill";
            this.Load += new System.EventHandler(this.Bill_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private Guna.UI2.WinForms.Guna2Button guna2Button3;
        private Guna.UI2.WinForms.Guna2Button guna2Button2;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private Guna.UI2.WinForms.Guna2TextBox txttot;
        private Guna.UI2.WinForms.Guna2TextBox txttotnights;
        private Guna.UI2.WinForms.Guna2TextBox txtrprice;
        private Guna.UI2.WinForms.Guna2TextBox txtrid;
        private System.Windows.Forms.RichTextBox txtResult;
        private Guna.UI2.WinForms.Guna2Button guna2Button4;
    }
}